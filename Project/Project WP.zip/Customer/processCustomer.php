<?php

include "customer.php";
//print_r($_POST);
if(isSet($_POST['deleteCustomerButton'])){
	deleteCustomer();
	header('Location: customerList.php');
}
else if(isSet($_POST['saveCustomerButton'])){
	//echo 'nak save new record';
	addCustomer();
	header('Location: customerList.php');	//redirect
}
else if(isSet($_POST['updateCustomerButton'])){
	updateCustomer();
	//header('Location: customerList.php');

}else if(isSet($_POST['updateCustomerPersonalButton'])){
		updateCustomer();
		header('Location: profileCustomer.php');

}else if(isSet($_POST['loginCustomerButton"'])){
	
	
}
else{
	if((isSet($_POST['registerCustomerButton']))); // kalau tak ada input atau email sama keluar register.php semula!!
	register();
	header('Location:../main/mainPage.php');	//redirect
}


?>