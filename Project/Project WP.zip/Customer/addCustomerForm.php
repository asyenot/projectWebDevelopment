<!DOCTYPE html>
<html>
<body>
<div class="w3-container">
<form action="processCustomer.php" method="POST">
    <input type="text" name="customerId" placeholder="Enter Customer Id"><br>
    <input type="text" name="custName" placeholder="Enter Customer Name"><br>
    <input type="text" name="phoneNumber" placeholder="Enter Phone Number"><br>
    <input type="text" name="email" placeholder="Enter Email"><br>
    <input type="submit" name="saveCustomerButton" value="Save"><br>

</form>
</div>
<?php 

?>

    
</body>

</html>