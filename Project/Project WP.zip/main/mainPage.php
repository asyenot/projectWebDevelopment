<!DOCTYPE html>
<html lang="en">
<head>
<title>FACILITY INFORMATION</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
<style>
body,h1,h2,h3,h4,h5 {font-family: "Poppins", sans-serif}
body {font-size:16px;}
a{text-decoration: none;} 
</style>
</head>
<body>

<!-- Sidebar/menu -->
<nav class="w3-bar w3-red" id="navbar"><br>
  <div class="w3-container">
    <h3 class="w3-padding-10"><span>UniRent Hub</span></h3>
  </div>

</nav>

<div class="w3-display-middle w3-panel w3-border  w3-round-xxlarge w3-pale-red w3-border-red" style="padding: 70px;padding-right: 90px;"> 
<h1 class="w3-xxxlarge w3-text-white  w3-red w3-center w3-round-xlarge" style="width:110%"><b><a href="../login/loginStaff.php">Staff</a></b></h1><br>
<h1 class="w3-xxxlarge w3-text-white w3-red w3-center w3-round-xlarge" style="width:110%" ><b><a href="../login/loginCustomer.php">Customer</a></b></h1>
<p class=" w3-text-red w3-center" style="padding-left: 40px;"><b><a href="../Customer/register.php">no account? Sign Up</a></b></p>
</div>

</body>   
</html>
