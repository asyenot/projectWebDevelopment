<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<?php
session_start(); 
include "user.php";
$_SESSION['userId']=$_POST['userId'];  
$_SESSION['password']=$_POST['password'];  
$_SESSION['curTime']=time();


// username and password sent from form 
$username=$_POST['userId']; 
$password=$_POST['password']; 


$isValidUser = validatePassword($username,$password);

if($isValidUser)
	{
	$userType=getUserType($username);
		if($userType =='STAFF')
			header("location: ../main/mainStaff.php"); // redirect to admin page
		else{
			echo '<div class="w3-container" style="width:80%; margin:0 auto;">';
			echo "<center><br><br>Wrong Username or Password";
			echo '<br><br span class="w3-right w3-padding w3-hide-large w3-large"><br><a href="loginStaff.php">Try Again?</a></span>';
			echo '</div></center>';
		}
	}
else {
	echo '<div class="w3-container" style="width:80%; margin:0 auto;">';
	echo "<center><br><br>Wrong Username or Password";
	echo '<br><br span class="w3-right w3-padding w3-hide-large w3-large"><br><a href="loginStaff.php">Try Again?</a></span>';
	echo '</div></center>';
	}
?>
	
